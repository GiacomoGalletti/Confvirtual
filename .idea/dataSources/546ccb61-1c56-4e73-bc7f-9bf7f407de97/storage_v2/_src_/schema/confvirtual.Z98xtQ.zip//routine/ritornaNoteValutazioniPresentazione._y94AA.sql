create
    definer = root@localhost procedure ritornaNoteValutazioniPresentazione(IN in_codiceSessione int, IN in_codicePresentazione int)
BEGIN
    SELECT note as NoteVoto
    FROM valutazione
    WHERE codiceSessione = in_codiceSessione and codicePresentazione = in_codicePresentazione;
END;

