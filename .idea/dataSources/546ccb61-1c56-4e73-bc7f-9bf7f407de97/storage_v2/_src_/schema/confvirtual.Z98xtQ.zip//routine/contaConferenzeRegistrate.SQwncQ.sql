create
    definer = root@localhost procedure contaConferenzeRegistrate()
BEGIN
SELECT count(*) AS numConferenzeRegistrate
FROM CONFERENZA;
END;

