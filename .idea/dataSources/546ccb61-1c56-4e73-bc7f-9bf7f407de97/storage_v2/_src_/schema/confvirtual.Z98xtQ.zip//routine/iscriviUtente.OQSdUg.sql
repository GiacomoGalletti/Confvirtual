create
    definer = root@localhost procedure iscriviUtente(IN in_userNameUtente varchar(50),
                                                     IN in_annoEdizioneconferenza year,
                                                     IN in_acronimoConferenza varchar(50))
BEGIN
    insert into utenteregistrato(userNameUtente,annoEdizioneConferenza,acronimoConferenza) values (in_userNameUtente,in_annoEdizioneconferenza,in_acronimoConferenza);
END;

