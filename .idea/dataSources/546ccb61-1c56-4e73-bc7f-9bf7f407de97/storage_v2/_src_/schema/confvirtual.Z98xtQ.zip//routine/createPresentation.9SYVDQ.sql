create
    definer = root@localhost procedure createPresentation(IN in_codiceSessione int, IN in_oraInizio time, IN in_oraFine time)
BEGIN
insert into presentazione(codiceSessione,oraInizio,oraFine) values (in_codiceSessione,in_oraInizio,in_oraFine);
END;

