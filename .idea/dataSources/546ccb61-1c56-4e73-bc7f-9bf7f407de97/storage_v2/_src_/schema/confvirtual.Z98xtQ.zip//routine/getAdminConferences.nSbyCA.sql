create
    definer = root@localhost procedure getAdminConferences(IN userName int)
BEGIN
    select *
    from conferenza
    where conferenza.acronimo in (
        SELECT creatoriconferenza.acronimoConferenza
        from creatoriconferenza
        where creatoriconferenza.userNameUtente = userName
        );
END;

