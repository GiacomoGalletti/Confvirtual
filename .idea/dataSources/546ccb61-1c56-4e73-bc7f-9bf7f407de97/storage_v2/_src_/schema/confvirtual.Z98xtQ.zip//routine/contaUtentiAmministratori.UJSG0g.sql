create
    definer = root@localhost procedure contaUtentiAmministratori()
BEGIN
SELECT count(*) AS numUtentiAmministratori
FROM UTENTE
WHERE userName IN (SELECT userNameUtente FROM AMMINISTRATORE);
END;

