create
    definer = root@localhost procedure ritornaGiorniConferenza(IN in_acronimo varchar(10), IN in_annoEdizioneConferenza year)
BEGIN
    select giorno
    from DATACONFERENZA
    where (DATACONFERENZA.acronimoConferenza = in_acronimo) AND (DATACONFERENZA.annoEdizioneConferenza = in_annoEdizioneConferenza);
END;

