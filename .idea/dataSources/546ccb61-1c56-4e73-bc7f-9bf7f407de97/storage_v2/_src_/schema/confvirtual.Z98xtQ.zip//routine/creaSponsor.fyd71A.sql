create
    definer = root@localhost procedure creaSponsor(IN in_nome varchar(50), IN in_immagineLogo varchar(260))
BEGIN
    insert into SPONSOR(immagineLogo,nome) values (in_immagineLogo,in_nome);
END;

