create
    definer = root@localhost procedure promuoviUtenteAPresenter(IN in_userNameUtente varchar(50))
BEGIN
    insert into presenter(userNameUtente) values (in_userNameUtente);
END;

