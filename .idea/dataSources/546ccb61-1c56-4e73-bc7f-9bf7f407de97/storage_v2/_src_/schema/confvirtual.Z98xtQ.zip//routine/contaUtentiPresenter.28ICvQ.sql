create
    definer = root@localhost procedure contaUtentiPresenter()
BEGIN
	SELECT count(*) AS numUtentiPresenter
    FROM UTENTE
    WHERE userName IN (SELECT userNameUtente FROM PRESENTER);
END;

