create
    definer = root@localhost procedure insertRating(IN in_usernameUtente varchar(50), IN in_codicePresentaione int,
                                                    IN in_codiceSessione int, IN in_voto int, IN in_note varchar(50))
BEGIN
    insert into VALUTAZIONE(userNameUtente, codicePresentazione, codiceSessione, voto, note) values (in_usernameUtente,in_codicePresentaione,in_codiceSessione,in_voto,in_note );
END;

