create
    definer = root@localhost procedure checkUserExists(IN nomeUtente varchar(50), IN pswd varchar(50))
BEGIN
	SELECT userName
	FROM UTENTE
	WHERE UTENTE.userName = nomeUtente AND UTENTE.pswd = pswd;
END;

