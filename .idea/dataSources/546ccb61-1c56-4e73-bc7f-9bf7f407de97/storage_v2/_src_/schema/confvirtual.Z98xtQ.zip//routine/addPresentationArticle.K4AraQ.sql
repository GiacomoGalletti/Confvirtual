create
    definer = root@localhost procedure addPresentationArticle(IN in_codiceSessione int, IN in_oraInizio time,
                                                              IN in_oraFine time, IN in_titolo varchar(50),
                                                              IN in_filePdf varchar(260), IN in_numeroPagine int)
BEGIN
    DECLARE codice_presentazione INT unsigned DEFAULT 0;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            ROLLBACK;
            SELECT 'ERROR' AS risultato;
        END;
    start transaction;
    call createPresentation(in_codiceSessione,in_oraInizio,in_oraFine);
    SET codice_presentazione = (select max(codice) from presentazione where codiceSessione =  in_codiceSessione);
    call createArticolo (codice_presentazione,in_codiceSessione,in_titolo,in_filePdf,in_numeroPagine);
    SELECT 'OK' AS risultato;
    commit;
END;

