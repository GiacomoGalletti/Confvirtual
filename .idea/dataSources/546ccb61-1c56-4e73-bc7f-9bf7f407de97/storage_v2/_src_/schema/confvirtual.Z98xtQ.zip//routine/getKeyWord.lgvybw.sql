create
    definer = root@localhost procedure getKeyWord(IN in_codicePresentazione int, IN in_codiceSessione int)
BEGIN
    select parola from parolachiave where (codiceSessione = in_codiceSessione and codicePresentazione = in_codicePresentazione);
END;

