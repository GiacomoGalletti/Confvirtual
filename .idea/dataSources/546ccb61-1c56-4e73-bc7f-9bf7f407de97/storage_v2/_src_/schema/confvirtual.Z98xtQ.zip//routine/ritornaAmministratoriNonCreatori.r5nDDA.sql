create
    definer = root@localhost procedure ritornaAmministratoriNonCreatori(IN in_userNameUtente varchar(50),
                                                                        IN in_annoEdizioneConferenza year,
                                                                        IN in_acronimoConferenza varchar(50))
BEGIN
    select userName, nome, cognome, luogoNascita, dataNascita
    from utente
    where username in (select userNameUtente from amministratore where amministratore.userNameUtente <> in_userNameUtente)
      and username not in (select userNameUtente from creatoriconferenza where annoEdizioneConferenza = in_annoEdizioneConferenza and acronimoConferenza = in_acronimoConferenza);
END;

