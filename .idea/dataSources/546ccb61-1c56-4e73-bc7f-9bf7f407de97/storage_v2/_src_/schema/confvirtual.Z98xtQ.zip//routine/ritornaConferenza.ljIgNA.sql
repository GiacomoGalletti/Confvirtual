create
    definer = root@localhost procedure ritornaConferenza(IN in_acronimo varchar(10), IN in_annoEdizione year)
BEGIN
    select *
    from CONFERENZA
    where (CONFERENZA.acronimo = in_acronimo,CONFERENZA.annoEdizione = in_annoEdizione)
    ;
END;

