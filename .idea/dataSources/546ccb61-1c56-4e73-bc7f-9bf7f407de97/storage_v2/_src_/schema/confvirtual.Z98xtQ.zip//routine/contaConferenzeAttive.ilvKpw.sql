create
    definer = root@localhost procedure contaConferenzeAttive()
BEGIN
SELECT count(*) AS numConferenzeAttive
FROM CONFERENZA
WHERE statoSvolgimento = 'attiva';
END;

