create definer = root@localhost view conferenzevalide as
(
select `confvirtual`.`conferenza`.`annoEdizione`           AS `annoEdizione`,
       `confvirtual`.`conferenza`.`acronimo`               AS `acronimo`,
       `confvirtual`.`conferenza`.`totaleSponsorizzazioni` AS `totaleSponsorizzazioni`,
       `confvirtual`.`conferenza`.`immagineLogo`           AS `immagineLogo`,
       `confvirtual`.`conferenza`.`statoSvolgimento`       AS `statoSvolgimento`,
       `confvirtual`.`conferenza`.`nome`                   AS `nome`
from `confvirtual`.`conferenza`
where `confvirtual`.`conferenza`.`statoSvolgimento` = 'attiva');

