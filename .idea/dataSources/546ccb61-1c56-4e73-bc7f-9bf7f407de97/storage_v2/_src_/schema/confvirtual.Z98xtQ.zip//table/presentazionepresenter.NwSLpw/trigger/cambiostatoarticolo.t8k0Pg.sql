create definer = root@localhost trigger cambioStatoArticolo
    after insert
    on presentazionepresenter
    for each row
BEGIN
	UPDATE articolo, presentazionepresenter
    SET articolo.statoSvolgimento = 'coperto' WHERE articolo.codiceSessione = presentazionepresenter.codiceSessione AND articolo.codicePresentazione = presentazionepresenter.codicePresentazione;
END;

