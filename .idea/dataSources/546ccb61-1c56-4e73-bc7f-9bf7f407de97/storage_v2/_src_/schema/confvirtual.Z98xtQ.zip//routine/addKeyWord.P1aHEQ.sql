create
    definer = root@localhost procedure addKeyWord(IN in_codicePresentazione int, IN in_codiceSessione int,
                                                  IN in_parola varchar(20))
BEGIN
    INSERT INTO parolachiave (codicePresentazione, codiceSessione, parola) VALUES (in_codicePresentazione,in_codiceSessione,in_parola);
END;

