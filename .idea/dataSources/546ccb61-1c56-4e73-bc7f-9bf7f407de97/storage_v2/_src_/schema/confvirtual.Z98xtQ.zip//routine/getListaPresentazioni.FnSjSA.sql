create
    definer = root@localhost procedure getListaPresentazioni(IN in_acronimoConferenza varchar(10))
BEGIN
SELECT *
FROM presentazione
WHERE presentazione.codiceSessione IN (
SELECT sessione.codice
FROM sessione
WHERE sessione.acronimoConferenza = in_acronimoConferenza
);END;

