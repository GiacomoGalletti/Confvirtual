create
    definer = root@localhost procedure getAllPresentationInfo(IN in_codiceSessione int)
BEGIN
    select *
    from presentazione
    where presentazione.codiceSessione = in_codiceSessione
    order by numeroSequenza;
END;

