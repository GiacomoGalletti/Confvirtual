create definer = root@localhost view speakerconvalutazione as
select `confvirtual`.`presentazionespeaker`.`userNameUtente`      AS `userName`,
       `confvirtual`.`presentazionespeaker`.`codiceSessione`      AS `codiceSessione`,
       `confvirtual`.`presentazionespeaker`.`codicePresentazione` AS `codicePresentazione`
from `confvirtual`.`presentazionespeaker`
where (`confvirtual`.`presentazionespeaker`.`codiceSessione`,
       `confvirtual`.`presentazionespeaker`.`codicePresentazione`) in
      (select `confvirtual`.`valutazione`.`codiceSessione`, `confvirtual`.`valutazione`.`codicePresentazione`
       from `confvirtual`.`valutazione`);

