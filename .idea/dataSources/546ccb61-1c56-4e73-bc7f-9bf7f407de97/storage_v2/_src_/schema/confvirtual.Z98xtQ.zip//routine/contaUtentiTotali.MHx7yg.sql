create
    definer = root@localhost procedure contaUtentiTotali()
BEGIN
SELECT count(*) AS numUtentiTotali
FROM UTENTE;
END;

