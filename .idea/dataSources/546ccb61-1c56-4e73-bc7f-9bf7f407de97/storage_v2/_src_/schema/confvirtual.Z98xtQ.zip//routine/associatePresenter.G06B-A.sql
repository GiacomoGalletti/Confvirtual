create
    definer = root@localhost procedure associatePresenter(IN in_userNameUtente varchar(50),
                                                          IN in_titoloArticolo varchar(50),
                                                          IN in_codicePresentazione int, IN in_codiceSessione int)
BEGIN
    insert into presentazionepresenter (userNameUtente, titoloArticolo, codicePresentazione, codiceSessione) values (in_userNameUtente, in_titoloArticolo, in_codicePresentazione, in_codiceSessione);
END;

