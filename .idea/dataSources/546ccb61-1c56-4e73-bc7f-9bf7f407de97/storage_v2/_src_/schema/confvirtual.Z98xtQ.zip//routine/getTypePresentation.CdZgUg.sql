create
    definer = root@localhost procedure getTypePresentation(IN in_codicePresentazione int)
BEGIN  
  IF EXISTS (
	SELECT *
	FROM ARTICOLO
    WHERE ARTICOLO.codicePresentazione = in_codicePresentazione
  ) THEN (
	SELECT distinct 'articolo' AS tipoPresentazione
    FROM PRESENTAZIONE,ARTICOLO
    WHERE PRESENTAZIONE.codice = in_codicePresentazione
  );ELSE (
	SELECT distinct 'tutorial' AS tipoPresentazione
    FROM PRESENTAZIONE,TUTORIAL
    WHERE PRESENTAZIONE.codice = in_codicePresentazione
  );
END IF;
END;

