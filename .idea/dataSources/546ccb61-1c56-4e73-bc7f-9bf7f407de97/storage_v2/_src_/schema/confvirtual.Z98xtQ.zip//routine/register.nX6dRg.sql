create
    definer = root@localhost procedure register(IN inUnserName varchar(50), IN inPswd varchar(50),
                                                IN inName varchar(50), IN inSurname varchar(50),
                                                IN inBirthPlace varchar(50), IN inBirthday date)
BEGIN
insert into UTENTE(
    userName,
    nome,
    cognome,
    pswd,
    luogoNascita,
    dataNascita) values (
                            inUnserName,
                            inName,
                            inSurname,
                            inPswd,
                            inBirthPlace,
                            inBirthday
                        );
END;

