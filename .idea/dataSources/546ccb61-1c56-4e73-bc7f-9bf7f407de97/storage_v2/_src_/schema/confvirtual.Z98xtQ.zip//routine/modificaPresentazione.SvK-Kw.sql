create
    definer = root@localhost procedure modificaPresentazione(IN tipo varchar(20), IN in_codicePresentazione int,
                                                             IN in_codiceSessione int, IN in_titolo varchar(50),
                                                             IN in_filePdf varchar(260), IN in_numeroPagine int,
                                                             IN in_abstract varchar(500))
BEGIN
    IF (tipo = 'articolo') THEN
        UPDATE articolo
        SET titolo = in_titolo, filePdf = in_filePdf, numeroPagine = in_numeroPagine
        WHERE in_codicePresentazione = articolo.codicePresentazione AND in_codiceSessione = articolo.codiceSessione;
    ELSE IF (tipo = 'tutorial') THEN
        UPDATE tutorial
        SET titolo = in_titolo, abstract = in_abstract
        WHERE in_codicePresentazione = tutorial.codicePresentazione AND in_codiceSessione = tutorial.codiceSessione;
    END IF;
    END IF;
END;

