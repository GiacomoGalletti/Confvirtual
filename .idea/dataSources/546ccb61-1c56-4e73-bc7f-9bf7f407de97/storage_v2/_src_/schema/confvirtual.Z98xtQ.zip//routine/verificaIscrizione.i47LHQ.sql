create
    definer = root@localhost procedure verificaIscrizione(IN in_userNameUtente varchar(50),
                                                          IN in_acronimoConferenza varchar(50),
                                                          IN in_annoEdizioneconferenza year)
BEGIN
    SELECT * FROM utenteregistrato
    WHERE in_userNameUtente = userNameUtente AND in_acronimoConferenza=acronimoConferenza AND in_annoEdizioneconferenza=annoEdizioneconferenza;
END;

