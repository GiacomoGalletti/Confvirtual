create
    definer = root@localhost procedure associateSpeaker(IN in_userNameUtente varchar(50),
                                                        IN in_titoloTutorial varchar(50), IN in_codicePresentazione int,
                                                        IN in_codiceSessione int)
BEGIN
    insert into presentazionespeaker (userNameUtente, titoloTutorial, codicePresentazione, codiceSessione) values (in_userNameUtente, in_titoloTutorial, in_codicePresentazione, in_codiceSessione);
END;

