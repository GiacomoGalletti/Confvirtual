create
    definer = root@localhost procedure ritornaSpeaker()
BEGIN
    select foto,userName,nome,cognome,nomeUniversita,nomeDipartimento
    from UTENTE join SPEAKER on UTENTE.userName = SPEAKER.userNameUtente;
END;

