create definer = root@localhost trigger contatorePresentazioni
    after delete
    on presentazione
    for each row
BEGIN
    UPDATE sessione
    SET numeroPresentazioni = (
        SELECT count(codiceSessione)
        FROM presentazione
        WHERE sessione.codice = presentazione.codiceSessione GROUP BY codiceSessione);
END;

