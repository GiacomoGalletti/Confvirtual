create
    definer = root@localhost procedure classificaPresenter()
BEGIN
    SELECT userName, avg(voto) AS mediaVoti
    FROM presenterConValutazione INNER JOIN valutazione ON presenterConValutazione.codiceSessione = valutazione.codiceSessione AND presenterConValutazione.codicePresentazione = valutazione.codicePresentazione
    GROUP BY userName
    ORDER BY mediaVoti desc;
END;

