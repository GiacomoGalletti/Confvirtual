create
    definer = root@localhost procedure checkUserType(IN nomeUtente varchar(50))
BEGIN
DECLARE res_type varchar(20) DEFAULT 'utente'; #default fallisce
	if exists(
		SELECT userNameUtente
		FROM amministratore
		WHERE amministratore.userNameUtente = nomeUtente
	)
	THEN 
		set res_type = 'amministratore';
ELSE
		if exists (
			SELECT userNameUtente
			FROM speaker
			WHERE speaker.userNameUtente = nomeUtente
        )
        then
			set res_type = 'speaker';
else
			if exists (
				SELECT userNameUtente
				FROM presenter
				WHERE presenter.userNameUtente = nomeUtente
            )
            then
				set res_type = 'presenter';
end if;
end if;
END IF;
select res_type;
END;

