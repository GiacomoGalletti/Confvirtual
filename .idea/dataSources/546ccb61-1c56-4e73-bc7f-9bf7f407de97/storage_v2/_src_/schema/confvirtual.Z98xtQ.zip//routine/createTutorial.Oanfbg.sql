create
    definer = root@localhost procedure createTutorial(IN in_codicePresentazione int, IN in_codiceSessione int,
                                                      IN in_titolo varchar(50), IN in_abstract varchar(500))
BEGIN
    INSERT INTO  tutorial(codicePresentazione, codiceSessione, titolo, abstract)VALUES(in_codicePresentazione,in_codiceSessione,in_titolo,in_abstract);
END;

