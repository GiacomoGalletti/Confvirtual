create
    definer = root@localhost procedure createTutorial(IN in_codicePresentazione int, IN in_codiceSessione int,
                                                      IN in_titolo varchar(50), IN in_abstract varchar(500))
BEGIN
    #--CALL createPresentation(1, '16:15:00', '17:15:00');	testare
    INSERT INTO  tutorial(codicePresentazione, codiceSessione, titolo)VALUES(in_codicePresentazione,in_codiceSessione,in_titolo,in_abstract);
END;

