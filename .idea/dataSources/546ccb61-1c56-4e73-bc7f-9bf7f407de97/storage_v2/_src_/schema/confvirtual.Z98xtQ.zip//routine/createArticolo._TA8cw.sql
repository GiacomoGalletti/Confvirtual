create
    definer = root@localhost procedure createArticolo(IN in_codicePresentazione int, IN in_codiceSessione int,
                                                      IN in_titolo varchar(50), IN in_filePdf varchar(260),
                                                      IN in_numeroPagine int)
BEGIN
INSERT INTO  articolo(codicePresentazione,codiceSessione,titolo,filePDF,numeroPagine)VALUES(in_codicePresentazione,in_codiceSessione, in_titolo, in_filePdf, in_numeroPagine);
END;

