create
    definer = root@localhost procedure ritornaAmministratori()
BEGIN
    select *
    from UTENTE join AMMINISTRATORE on UTENTE.userName = AMMINISTRATORE.userNameUtente;
END;

