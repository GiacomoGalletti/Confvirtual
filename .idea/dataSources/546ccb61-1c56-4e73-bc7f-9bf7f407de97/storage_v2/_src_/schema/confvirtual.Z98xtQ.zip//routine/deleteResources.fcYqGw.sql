create
    definer = root@localhost procedure deleteResources(IN in_codicePresentazione int, IN in_codiceSessione int)
BEGIN
    DELETE FROM risorsatutorial WHERE in_codicePresentazione = risorsatutorial.codicePresentazione AND in_codiceSessione = risorsatutorial.codiceSessione;
END;

