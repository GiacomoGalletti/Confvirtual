create
    definer = root@localhost procedure getSessionsFromConfrernce(IN in_acronimoConferenza varchar(50),
                                                                 IN in_annoEdizioneConferenza year)
BEGIN
    select *
    from sessione
    where sessione.acronimoConferenza = in_acronimoConferenza AND sessione.annoEdizioneConferenza = in_annoEdizioneConferenza;
END;

