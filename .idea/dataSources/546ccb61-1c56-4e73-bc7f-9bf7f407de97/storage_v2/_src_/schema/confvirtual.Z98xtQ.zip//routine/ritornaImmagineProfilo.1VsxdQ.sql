create
    definer = root@localhost procedure ritornaImmagineProfilo(IN in_username varchar(50), IN in_tipo varchar(20))
BEGIN
    IF (in_tipo = 'speaker') THEN
        select foto
        from speaker
        where userNameUtente = in_username;
    ELSE IF (in_tipo = 'presenter') THEN
        select foto
        from presenter
        where userNameUtente = in_username;
    END IF;
    END IF;
END;

