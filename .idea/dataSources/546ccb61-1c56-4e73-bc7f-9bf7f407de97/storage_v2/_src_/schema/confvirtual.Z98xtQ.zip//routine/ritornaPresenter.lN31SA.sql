create
    definer = root@localhost procedure ritornaPresenter()
BEGIN
select foto,userName,nome,cognome,nomeUniversita,nomeDipartimento
from UTENTE join PRESENTER on UTENTE.userName = PRESENTER.userNameUtente;
END;

