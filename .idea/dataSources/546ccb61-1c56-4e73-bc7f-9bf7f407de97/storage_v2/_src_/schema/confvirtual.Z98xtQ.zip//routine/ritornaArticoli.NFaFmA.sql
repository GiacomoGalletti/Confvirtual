create
    definer = root@localhost procedure ritornaArticoli(IN in_userNameUtente varchar(50))
BEGIN
select *
from ARTICOLO
where (ARTICOLO.codicePresentazione,ARTICOLO.codiceSessione) not in (
	select codicePresentazione,codiceSessione
    from PRESENTAZIONEPRESENTER
    where PRESENTAZIONEPRESENTER.userNameUtente = in_userNameUtente
);
END;

