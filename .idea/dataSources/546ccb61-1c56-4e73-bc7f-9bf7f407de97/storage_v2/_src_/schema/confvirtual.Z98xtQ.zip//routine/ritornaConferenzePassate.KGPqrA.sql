create
    definer = root@localhost procedure ritornaConferenzePassate()
BEGIN
select *
from CONFERENZA
where (CONFERENZA.statoSvolgimento = 'completata');
END;

