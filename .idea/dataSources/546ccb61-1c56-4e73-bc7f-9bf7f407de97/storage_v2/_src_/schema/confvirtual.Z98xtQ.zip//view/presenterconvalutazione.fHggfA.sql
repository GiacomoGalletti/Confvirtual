create definer = root@localhost view presenterconvalutazione as
select `confvirtual`.`presentazionepresenter`.`userNameUtente`      AS `userName`,
       `confvirtual`.`presentazionepresenter`.`codiceSessione`      AS `codiceSessione`,
       `confvirtual`.`presentazionepresenter`.`codicePresentazione` AS `codicePresentazione`
from `confvirtual`.`presentazionepresenter`
where (`confvirtual`.`presentazionepresenter`.`codiceSessione`,
       `confvirtual`.`presentazionepresenter`.`codicePresentazione`) in
      (select `confvirtual`.`valutazione`.`codiceSessione`, `confvirtual`.`valutazione`.`codicePresentazione`
       from `confvirtual`.`valutazione`);

