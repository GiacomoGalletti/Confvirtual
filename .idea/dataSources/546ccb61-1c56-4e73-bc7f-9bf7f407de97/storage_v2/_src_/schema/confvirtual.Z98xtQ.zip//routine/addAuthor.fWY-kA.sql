create
    definer = root@localhost procedure addAuthor(IN in_codicePresentazione int, IN in_codiceSessione int,
                                                 IN in_nome varchar(50), IN in_cognome varchar(50))
BEGIN
    INSERT INTO AUTORE (codicePresentazione, codiceSessione, nome, cognome) VALUES (in_codicePresentazione,in_codiceSessione,in_nome,in_cognome);
END;

