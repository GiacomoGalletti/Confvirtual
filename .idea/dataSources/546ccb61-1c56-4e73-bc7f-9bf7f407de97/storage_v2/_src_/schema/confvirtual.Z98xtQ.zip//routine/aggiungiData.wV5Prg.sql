create
    definer = root@localhost procedure aggiungiData(IN in_giorno date, IN in_annoEdizione year, IN in_acronimo varchar(10))
BEGIN    
	insert into DATACONFERENZA(giorno,annoEdizioneConferenza,acronimoConferenza) values (in_giorno,in_annoEdizione,in_acronimo);
END;

