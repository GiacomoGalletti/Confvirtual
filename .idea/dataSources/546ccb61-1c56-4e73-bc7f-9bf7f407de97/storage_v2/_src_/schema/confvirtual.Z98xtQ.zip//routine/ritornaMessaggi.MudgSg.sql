create
    definer = root@localhost procedure ritornaMessaggi(IN in_codice_sessione int)
BEGIN
    select *
    from messaggio
    where messaggio.codiceSessione = in_codice_sessione;
END;

