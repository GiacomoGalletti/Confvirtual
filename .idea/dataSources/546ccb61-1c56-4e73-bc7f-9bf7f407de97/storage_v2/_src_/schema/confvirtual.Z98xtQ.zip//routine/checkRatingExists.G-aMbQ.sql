create
    definer = root@localhost procedure checkRatingExists(IN in_userNameUtente varchar(50),
                                                         IN in_codicePresentazione int, IN in_codiceSessione int)
BEGIN

    SELECT *
    FROM valutazione
    WHERE in_userNameUtente = userNameUtente AND in_codicePresentazione = codicePresentazione AND in_codiceSessione = codiceSessione;

END;

