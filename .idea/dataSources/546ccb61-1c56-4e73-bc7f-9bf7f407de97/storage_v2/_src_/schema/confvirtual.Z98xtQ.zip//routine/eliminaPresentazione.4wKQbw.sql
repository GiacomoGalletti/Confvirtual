create
    definer = root@localhost procedure eliminaPresentazione(IN in_codicePresentazione int, IN in_codiceSessione int)
BEGIN
    DELETE FROM presentazione WHERE in_codicePresentazione = presentazione.codice AND in_codiceSessione = presentazione.codiceSessione;
END;

