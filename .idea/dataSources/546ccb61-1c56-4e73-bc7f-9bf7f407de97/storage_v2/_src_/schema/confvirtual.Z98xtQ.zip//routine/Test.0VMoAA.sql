create
    definer = root@localhost procedure Test()
BEGIN
	declare counter int default 1;
    declare a bool default true;
    declare dateList varchar(100);
    SET dateList = '05-04-2022,28-04-2022,15-04-2022,08-04-2022,12-04-2022';
    DROP TABLE IF EXISTS temp_data;
    CREATE TEMPORARY TABLE temp_data(
		tempDate varchar(20)
    );
    INSERT INTO temp_data
    SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(dateList, ',', 1), ',', -1);
    
    WHILE a = true DO
		IF ((SELECT IF(strcmp(SUBSTRING_INDEX(SUBSTRING_INDEX(dateList, ',', counter), ',', -1),
									 SUBSTRING_INDEX(SUBSTRING_INDEX(dateList, ',', counter + 1), ',', -1)) = 0, "YES",
									 SUBSTRING_INDEX(SUBSTRING_INDEX(dateList, ',', counter + 1), ',', -1))) != "YES")
		THEN INSERT INTO temp_data SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(dateList, ',', counter + 1), ',', -1);
			 SET counter = counter + 1;
		ELSE SET a = false;
		END IF;
	END WHILE;
    
    SELECT * FROM temp_data;
END;

