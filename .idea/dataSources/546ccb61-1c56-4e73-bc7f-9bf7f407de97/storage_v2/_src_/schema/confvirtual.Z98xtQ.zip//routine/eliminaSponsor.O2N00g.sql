create
    definer = root@localhost procedure eliminaSponsor(IN in_nome varchar(50))
BEGIN
    DELETE FROM sponsor WHERE in_nome = sponsor.nome;
END;

