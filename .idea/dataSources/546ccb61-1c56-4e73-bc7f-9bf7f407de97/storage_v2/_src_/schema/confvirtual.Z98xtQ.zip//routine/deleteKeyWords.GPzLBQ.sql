create
    definer = root@localhost procedure deleteKeyWords(IN in_codicePresentazione int, IN in_codiceSessione int)
BEGIN
    DELETE FROM parolachiave WHERE in_codicePresentazione = parolachiave.codicePresentazione AND in_codiceSessione = parolachiave.codiceSessione;
END;

