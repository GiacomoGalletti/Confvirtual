create
    definer = root@localhost procedure ritornaInfoValutazioni(IN in_codiceSessione int, IN in_codicePresentazione int)
BEGIN
    SELECT *
    FROM valutazione
    WHERE codiceSessione = in_codiceSessione and codicePresentazione = in_codicePresentazione;
END;

