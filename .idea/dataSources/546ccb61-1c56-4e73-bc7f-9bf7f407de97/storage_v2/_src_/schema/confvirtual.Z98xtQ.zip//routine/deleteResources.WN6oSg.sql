create
    definer = root@localhost procedure deleteResources(IN in_codicePresentazione int, IN in_codiceSessione int,
                                                       IN in_link varchar(260), IN in_descrizione varchar(100))
BEGIN
    INSERT INTO risorsatutorial (codicePresentazione, codiceSessione, link, descrizione) VALUES (in_codicePresentazione,in_codiceSessione,in_link,in_descrizione);
END;

