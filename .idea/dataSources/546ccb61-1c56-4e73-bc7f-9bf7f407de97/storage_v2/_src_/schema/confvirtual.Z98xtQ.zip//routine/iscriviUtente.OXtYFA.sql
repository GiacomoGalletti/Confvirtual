create
    definer = root@localhost procedure iscriviUtente(IN in_userNameUtente varchar(50),
                                                     IN in_acronimoConferenza varchar(50),
                                                     IN in_annoEdizioneconferenza year)
BEGIN
    insert into utenteregistrato(userNameUtente,acronimoConferenza,annoEdizioneConferenza) values (in_userNameUtente,in_acronimoConferenza,in_annoEdizioneconferenza);
END;

