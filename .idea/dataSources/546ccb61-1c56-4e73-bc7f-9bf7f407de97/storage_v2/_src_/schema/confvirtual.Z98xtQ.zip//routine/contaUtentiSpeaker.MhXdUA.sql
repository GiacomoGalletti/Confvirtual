create
    definer = root@localhost procedure contaUtentiSpeaker()
BEGIN
SELECT count(*) AS numUtentiSpeaker
FROM UTENTE
WHERE userName IN (SELECT userNameUtente FROM SPEAKER);
END;

