create
    definer = root@localhost procedure ordinamentoSequenzePresentazioni(IN in_codiceSessione int)
BEGIN
    DECLARE done INT DEFAULT 0;
    DECLARE orafin INT;
    DECLARE nseq INT;
    DECLARE orafinale CURSOR FOR SELECT presentazione.oraFine FROM presentazione WHERE presentazione.codiceSessione = in_codiceSessione ORDER BY presentazione.oraFine;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    OPEN orafinale;

    FETCH orafinale INTO orafin;

    SET nseq = 1;

    REPEAT
        UPDATE presentazione SET numeroSequenza = nseq WHERE presentazione.oraFine = orafin AND presentazione.codiceSessione = in_codiceSessione;
        FETCH orafinale INTO orafin;
        SET nseq = nseq + 1;
    UNTIL done = 1 END REPEAT;

    CLOSE orafinale;
END;

