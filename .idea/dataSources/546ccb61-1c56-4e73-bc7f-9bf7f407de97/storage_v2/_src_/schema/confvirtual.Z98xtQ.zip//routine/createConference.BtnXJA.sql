create
    definer = root@localhost procedure createConference(IN in_annoEdizione year, IN in_acronimo varchar(10),
                                                        IN in_immagineLogo varchar(260), IN in_nome varchar(50),
                                                        IN in_userName varchar(50))
BEGIN  
	insert into CONFERENZA(annoEdizione,acronimo,immagineLogo,nome) values (in_annoEdizione,in_acronimo,in_immagineLogo,in_nome);
	insert into CREATORICONFERENZA (userNameUtente,annoEdizioneConferenza,acronimoConferenza) values (in_userName, in_annoEdizione, in_acronimo);
END;

