create
    definer = root@localhost procedure ritornaTutorial(IN in_userNameUtente varchar(50))
BEGIN
    select *
    from TUTORIAL
    where (TUTORIAL.codicePresentazione,TUTORIAL.codiceSessione) in (
        select codicePresentazione,codiceSessione
        from PRESENTAZIONESPEAKER
        where PRESENTAZIONESPEAKER.userNameUtente = in_userNameUtente
    ) AND TUTORIAL.codiceSessione IN (
        select codice
        from sessione,conferenza
        where sessione.acronimoConferenza = conferenza.acronimo and conferenza.statoSvolgimento = 'attiva'
    );
END;

