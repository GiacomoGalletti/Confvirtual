create
    definer = root@localhost procedure ritornaTutorial(IN in_userNameUtente varchar(50))
BEGIN
    select *
    from TUTORIAL
    where (TUTORIAL.codicePresentazione,TUTORIAL.codiceSessione) not in (
        select codicePresentazione,codiceSessione
        from PRESENTAZIONESPEAKER
        where PRESENTAZIONESPEAKER.userNameUtente = in_userNameUtente
    );
END;

