create
    definer = root@localhost procedure deleteAuthors(IN in_codicePresentazione int, IN in_codiceSessione int)
BEGIN
    DELETE FROM autore WHERE in_codicePresentazione = autore.codicePresentazione AND in_codiceSessione = autore.codiceSessione;
END;

