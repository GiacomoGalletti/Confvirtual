create definer = root@localhost trigger contatorePresentazioniOnInsert
    after insert
    on presentazione
    for each row
BEGIN
    UPDATE sessione
    SET numeroPresentazioni = (
        SELECT count(codiceSessione)
        FROM presentazione
        WHERE sessione.codice = presentazione.codiceSessione);
END;

