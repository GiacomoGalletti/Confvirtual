create
    definer = root@localhost procedure aggiungiCreatoreConferenza(IN in_userNameUtente varchar(50),
                                                                  IN in_annoEdizioneConferenza year,
                                                                  IN in_acronimoConferenza varchar(50))
BEGIN
    insert into creatoriconferenza(userNameUtente, annoEdizioneConferenza, acronimoConferenza) values (in_userNameUtente, in_annoEdizioneConferenza, in_acronimoConferenza);
END;

