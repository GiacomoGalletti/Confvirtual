create
    definer = root@localhost procedure promuoviUtenteASpeaker(IN in_userNameUtente varchar(50))
BEGIN
    insert into speaker(userNameUtente) values (in_userNameUtente);
END;

