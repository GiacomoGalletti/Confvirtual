create
    definer = root@localhost procedure ritornaIscrizioniConferenze(IN in_userNameUtente varchar(50))
BEGIN
    select * from conferenzevalide,utenteregistrato where conferenzevalide.acronimo = utenteregistrato.acronimoConferenza and conferenzevalide.annoEdizione = utenteregistrato.annoEdizioneconferenza and in_userNameUtente = utenteregistrato.userNameUtente;
END;

