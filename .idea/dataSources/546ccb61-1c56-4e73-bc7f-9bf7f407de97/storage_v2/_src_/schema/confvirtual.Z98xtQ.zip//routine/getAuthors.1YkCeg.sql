create
    definer = root@localhost procedure getAuthors(IN in_codicePresentazione int, IN in_codiceSessione int)
BEGIN
    select nome,cognome from autore where (codiceSessione = in_codiceSessione and codicePresentazione = in_codicePresentazione);
END;

