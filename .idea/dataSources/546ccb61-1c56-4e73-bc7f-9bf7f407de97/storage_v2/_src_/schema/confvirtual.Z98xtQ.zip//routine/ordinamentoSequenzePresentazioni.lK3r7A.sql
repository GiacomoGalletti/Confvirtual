create
    definer = root@localhost procedure ordinamentoSequenzePresentazioni()
BEGIN
	DECLARE done INT DEFAULT 0;
	DECLARE ora INT;
    DECLARE sessioncode INT;
    DECLARE oldsessioncode INT;
    DECLARE nseq INT;
	DECLARE getora CURSOR FOR SELECT presentazione.oraFine FROM presentazione INNER JOIN sessione ON presentazione.codiceSessione = sessione.codice 
						      ORDER BY presentazione.oraFine AND presentazione.codiceSessione;
	DECLARE getsessioncode CURSOR FOR SELECT presentazione.codiceSessione FROM presentazione INNER JOIN sessione ON presentazione.codiceSessione = sessione.codice 
									  ORDER BY presentazione.oraFine AND presentazione.codiceSessione;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    
    OPEN getora;
    OPEN getsessioncode;
    
    FETCH getora INTO ora;
    FETCH getsessioncode INTO sessioncode;
    
    SET @nseq = 1;
    SET oldsessioncode = sessioncode;
    
    REPEAT
		IF (sessioncode > oldsessioncode) THEN SET @nseq = 1;
        END IF;
        UPDATE presentazione SET numeroSequenza = @nseq WHERE presentazione.oraFine = ora AND presentazione.codiceSessione = sessioncode;
        SET @nseq = @nseq + 1;
        SET oldsessioncode = sessioncode;
        FETCH getora INTO ora;
		FETCH getsessioncode INTO sessioncode;
	UNTIL done = 1 END REPEAT;
    
    CLOSE getora;
    CLOSE getsessioncode;
END;

