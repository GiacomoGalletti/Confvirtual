create
    definer = root@localhost procedure ritornaRisorseTutorial(IN in_codiceSessione int, IN in_codicePresentazione int)
BEGIN
    SELECT *
    FROM risorsatutorial
    WHERE codiceSessione = in_codiceSessione and codicePresentazione = in_codicePresentazione;
END;

