create
    definer = root@localhost procedure ritornaConferenzeFuture(IN in_dataOggi date)
BEGIN
	select *
    from CONFERENZA
    where (CONFERENZA.acronimo,CONFERENZA.annoEdizione) IN (
		select acronimoConferenza, annoEdizioneConferenza
        from DATACONFERENZA
        where DATACONFERENZA.giorno >= in_dataOggi
    );
END;

