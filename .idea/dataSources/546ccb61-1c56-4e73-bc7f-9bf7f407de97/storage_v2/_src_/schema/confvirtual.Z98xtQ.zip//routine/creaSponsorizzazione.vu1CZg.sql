create
    definer = root@localhost procedure creaSponsorizzazione(IN in_importo double, IN in_annoEdizione year,
                                                            IN in_acronimo varchar(10), IN in_nome varchar(50))
BEGIN
    insert into sponsorizzazioni(importo,annoEdizioneConferenza,acronimoConferenza,nomeSponsor) values (in_importo,in_annoEdizione,in_acronimo,in_nome);

    END;

