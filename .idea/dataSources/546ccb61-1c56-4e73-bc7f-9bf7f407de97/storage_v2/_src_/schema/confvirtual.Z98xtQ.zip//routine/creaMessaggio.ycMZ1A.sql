create
    definer = root@localhost procedure creaMessaggio(IN in_codice_sessione int, IN in_userNameUtente varchar(50),
                                                     IN in_messaggio varchar(500), IN in_data date)
BEGIN
    insert into messaggio (codiceSessione,userNameUtente,testo,dataInvio) values (in_codice_sessione,in_userNameUtente, in_messaggio, in_data);
END;

