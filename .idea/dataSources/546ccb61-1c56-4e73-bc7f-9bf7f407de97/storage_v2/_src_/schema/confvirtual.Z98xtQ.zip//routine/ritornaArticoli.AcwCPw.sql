create
    definer = root@localhost procedure ritornaArticoli()
BEGIN
    select *
    from articolo
    where (articolo.statoSvolgimento = 'non coperto');
END;

