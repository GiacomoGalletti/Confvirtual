create
    definer = root@localhost procedure ritornaArticoli()
BEGIN
    select *
    from ARTICOLO
    where (ARTICOLO.codicePresentazione,ARTICOLO.codiceSessione) not in (
        select codicePresentazione,codiceSessione
        from PRESENTAZIONEPRESENTER
    );
END;

