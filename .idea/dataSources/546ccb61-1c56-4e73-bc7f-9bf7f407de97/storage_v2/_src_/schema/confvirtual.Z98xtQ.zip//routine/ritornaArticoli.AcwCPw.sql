create
    definer = root@localhost procedure ritornaArticoli()
BEGIN
    select *
    from articolo
    where (articolo.statoSvolgimento = 'non coperto') AND articolo.codiceSessione IN (
        select codice
        from sessione,conferenza
        where sessione.acronimoConferenza = conferenza.acronimo and conferenza.statoSvolgimento = 'attiva'
    );
END;

