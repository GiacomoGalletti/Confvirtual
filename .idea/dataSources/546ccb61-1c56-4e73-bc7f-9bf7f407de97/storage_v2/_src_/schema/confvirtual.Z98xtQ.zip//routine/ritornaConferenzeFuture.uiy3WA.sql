create
    definer = root@localhost procedure ritornaConferenzeFuture()
BEGIN
	select *
    from CONFERENZA
    where (CONFERENZA.statoSvolgimento = 'attiva');
END;

