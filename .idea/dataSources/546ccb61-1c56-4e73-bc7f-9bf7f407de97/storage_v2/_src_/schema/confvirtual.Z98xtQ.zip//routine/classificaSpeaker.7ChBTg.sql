create
    definer = root@localhost procedure classificaSpeaker()
BEGIN
    SELECT userName, avg(voto) AS mediaVoti
    FROM speakerConValutazione INNER JOIN valutazione ON speakerConValutazione.codiceSessione = valutazione.codiceSessione AND speakerConValutazione.codicePresentazione = valutazione.codicePresentazione
    GROUP BY userName
    ORDER BY mediaVoti desc;
END;

