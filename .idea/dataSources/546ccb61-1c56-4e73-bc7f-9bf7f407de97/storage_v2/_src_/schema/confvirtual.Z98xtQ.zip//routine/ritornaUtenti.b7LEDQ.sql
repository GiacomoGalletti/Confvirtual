create
    definer = root@localhost procedure ritornaUtenti()
BEGIN
    select userName, nome, cognome, luogoNascita, dataNascita
    from utente
    where username not in (select userNameUtente from speaker) and username not in (select userNameUtente from presenter);
END;

